Most of the programs running on windows are signed. The creators have a certificate which helps windows verify the file authenticity.
This app is not signed with any certificates, reason being the certifications of the apps are costly

This app is completely safe. The whole source code is available on GitHub https://github.com/ashvnv/Co-Win-Notifier
You can always check the source file for malicious codes

This app does not require standard installation like other programs and runs as a portable program

If you are unable to run the app, try disabling your antivirus

Read more on why windows considers non-signed programs virus: 
https://posts.specterops.io/what-is-it-that-makes-a-microsoft-executable-a-microsoft-executable-b43ac612195e

This is an open source program, which does not collect any user data. 
The app only accesses the CoWIN API for getting the slots information and Telegram API for sending alerts.

